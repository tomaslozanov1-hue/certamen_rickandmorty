const express = require('express');
const app = express();
const PORT = 3005;

// Archivos estáticos (HTML, CSS, JS)
app.use(express.static('public'));

// ============================================
// GET /api/personajes
// Devuelve los primeros 15 personajes
// ============================================

app.get('/api/personajes', async (req, res) => {

    try {

        // Pedir los 15 personajes en paralelo
        const datos = await Promise.all(
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map(id =>
                fetch(`https://rickandmortyapi.com/api/character/${id}`)
                    .then(res => res.json())
            )
        );

        // Quedarnos solo con los datos importantes
        const personajes = datos.map(p => ({
            id: p.id,
            nombre: p.name,
            estado: p.status,
            especie: p.species,
            genero: p.gender,
            imagen: p.image
        }));

        res.json(personajes);

    } catch (error) {

        res.status(500).json({
            error: 'Error del servidor'
        });
    }
});

// ============================================
// Iniciar servidor
// ============================================

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
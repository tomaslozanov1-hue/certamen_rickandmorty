// ============================================
// Referencias HTML
// ============================================

const lista = document.getElementById("contenedor");
const cargando = document.getElementById("cargando");
const error = document.getElementById("error");

// ============================================
// Cuando cargue la página
// ============================================

document.addEventListener("DOMContentLoaded", obtenerPersonajes);

// ============================================
// Obtener personajes desde la API
// ============================================

async function obtenerPersonajes() {

    try {

        const respuesta = await fetch("https://rickandmortyapi.com/api/character");

        if (!respuesta.ok) {
            throw new Error("Error al obtener datos");
        }

        const datos = await respuesta.json();

        mostrarPersonajes(datos.results);

        cargando.style.display = "none";

    } catch (err) {

        cargando.style.display = "none";
        error.textContent = "Ocurrió un error al cargar la API";

        console.log(err);
    }
}

// ============================================
// Mostrar personajes
// ============================================

function mostrarPersonajes(personajes) {

    personajes.forEach(personaje => {

        const tarjeta = document.createElement("div");
        tarjeta.classList.add("tarjeta");

        tarjeta.innerHTML = `
            <img src="${personaje.image}" alt="${personaje.name}">
            
            <div class="info">
                <h2>${personaje.name}</h2>
                <p><strong>Estado:</strong> ${personaje.status}</p>
                <p><strong>Especie:</strong> ${personaje.species}</p>
                <p><strong>Género:</strong> ${personaje.gender}</p>
            </div>
        `;

        contenedor.appendChild(tarjeta);
    });
}
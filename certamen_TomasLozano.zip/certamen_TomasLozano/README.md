Proyecto Rick and Morty API

Este proyecto consiste en una aplicación web desarrollada con Node.js, Express, HTML, CSS y JavaScript, la cual consume datos desde la API pública de Rick and Morty.

La aplicación obtiene y muestra los primeros 15 personajes de la serie utilizando peticiones HTTP a la API oficial:

Rick and Morty API

Objetivo del Proyecto

El objetivo principal es aprender a:

Crear un servidor con Express.
Consumir APIs externas.
Trabajar con archivos estáticos.
Utilizar fetch y funciones asíncronas.
Mostrar datos dinámicamente en el navegador.
Estructura del Proyecto

El proyecto está compuesto por los siguientes archivos:

project/Certamen_TomasLozano
│
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
│
├── server.js
├── package.json
└── node_modules/
Explicación General del Código
1. server.js

El archivo server.js corresponde al servidor principal de la aplicación.

Se utiliza Express para:

Crear el servidor web.
Servir archivos estáticos.
Crear una ruta API personalizada.
Consumir datos desde la API de Rick and Morty.
Funcionamiento
Importación de Express
const express = require('express');

Se importa la librería Express para poder crear el servidor.

Creación de la aplicación
const app = express();

Aquí se inicializa la aplicación Express.

Puerto del servidor
const PORT = 3000;

Define el puerto donde correrá la aplicación.

Archivos estáticos
app.use(express.static('public'));

Permite que el servidor pueda acceder a los archivos HTML, CSS y JavaScript que se encuentran dentro de la carpeta public.

Ruta API
app.get('/api/personajes', async (req, res) => {

Se crea una ruta llamada /api/personajes que devuelve información de personajes.

Consumo de la API
fetch(`https://rickandmortyapi.com/api/character/${id}`)

Se utiliza fetch para obtener los datos desde la API externa.

Promise.all
Promise.all(...)

Permite hacer múltiples peticiones al mismo tiempo para obtener los 15 personajes más rápido.

Filtrado de datos
const personajes = datos.map(p => ({

Se seleccionan solo los datos importantes:

id
nombre
estado
especie
género
imagen
Inicio del servidor
app.listen(PORT, () => {

Inicia el servidor en el puerto especificado.

2. index.html

El archivo index.html corresponde a la estructura principal de la página web.

Contiene:

El título.
El contenedor donde se mostrarán los personajes.
Mensajes de carga y error.
La conexión con style.css y app.js.
3. style.css

El archivo style.css se encarga del diseño visual de la aplicación.

Funciones principales
Cambiar colores de fondo.
Organizar las tarjetas con CSS Grid.
Aplicar estilos a textos e imágenes.
Crear efectos hover en las tarjetas.
4. app.js

El archivo app.js controla toda la lógica del frontend.

Funcionamiento
Obtener referencias HTML
const contenedor = document.getElementById("contenedor");

Permite acceder a elementos del HTML desde JavaScript.

Evento DOMContentLoaded
document.addEventListener("DOMContentLoaded", obtenerPersonajes);

Ejecuta la función cuando la página termina de cargar.

Fetch al servidor
fetch("/api/personajes")

Se realiza una petición al servidor Express para obtener los personajes.

Conversión a JSON
const datos = await respuesta.json();

Convierte la respuesta en un objeto JavaScript.

Mostrar personajes
mostrarPersonajes(datos);

Llama a una función que crea dinámicamente las tarjetas de personajes.

Creación dinámica de tarjetas
const tarjeta = document.createElement("div");

JavaScript crea elementos HTML automáticamente utilizando los datos recibidos.

5. package.json

El archivo package.json contiene la configuración del proyecto Node.js.

Incluye:

Nombre del proyecto.
Versión.
Scripts de ejecución.
Dependencias instaladas.
Dependencias
Express
"express": "^4.18.2"

Framework utilizado para crear el servidor web.

Scripts
Iniciar servidor
npm start

Ejecuta el servidor normalmente.

Modo desarrollo
npm run dev

Reinicia automáticamente el servidor cuando se realizan cambios.

Instalación del Proyecto
1. Instalar dependencias
npm install
2. Ejecutar servidor
npm start
3. Abrir en navegador
http://localhost:3000
Tecnologías Utilizadas
HTML5
CSS3
JavaScript
Node.js
Express
Rick and Morty API